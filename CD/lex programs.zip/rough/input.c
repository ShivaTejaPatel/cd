/*printing welcome message*/
int main(){
	//declaration
	int i=0;
	//printing welcome message
	printf("welcome to my world");
	return 0;
}
