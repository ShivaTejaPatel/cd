
int main(){
	
	int i=0;
	
	printf("welcome to my world");
	return 0;
}
