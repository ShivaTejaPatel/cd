//input file
/*THIS IS ME*/
void main(){
	//declaration
	printf("hello");
	//end
}
