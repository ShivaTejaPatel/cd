
void main()
{

printf("welcome");

}
